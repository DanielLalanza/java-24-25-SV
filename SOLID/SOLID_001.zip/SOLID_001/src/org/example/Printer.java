package org.example;

public class Printer {
    void printToHTML(){
        System.out.println("Transformar en HTML");
    }
    void printToJSON(){
        System.out.println("Transformar en JSON");
    }
    void printToXML(){
        System.out.println("Transformar en XML");
    }
}
