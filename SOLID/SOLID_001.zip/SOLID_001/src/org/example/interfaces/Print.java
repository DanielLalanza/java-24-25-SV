package org.example.interfaces;

public interface Print {
    void print(String cadenaATransformar);
}
