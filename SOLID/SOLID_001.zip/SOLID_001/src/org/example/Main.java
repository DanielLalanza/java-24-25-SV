package org.example;

import org.example.herencia.Reporte;
import org.example.printers.PrintToHTML;
import org.example.printers.PrintToJSON;
import org.example.printers.PrintToXML;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        Reporte printToJSON = new PrintToJSON("JSON");
        Reporte printToXML = new PrintToXML("XML");

        ArrayList<Reporte> lst = new ArrayList<>();
        lst.add(printToJSON);
        lst.add(printToXML);
    }
}