package org.example.herencia;

public class Reporte {
    //ATRIBUTOS
    protected String cadenaATransformar;
    //CONSTRUCTOR
    public Reporte(String cadena){
        this.cadenaATransformar = cadena;
    }
    //MÉTODOS

    //GETTER/SETTER
}
