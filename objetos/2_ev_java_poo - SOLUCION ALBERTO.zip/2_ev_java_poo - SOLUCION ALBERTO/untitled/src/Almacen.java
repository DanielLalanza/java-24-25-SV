import java.util.Arrays;


public class Almacen{
   private Producto inventario[];
   private int index = 0;

    public void agragarProductosInventario(Producto miProducto){
        this.inventario[index] = miProducto;
   }


    public void mostrarInventario(){
        System.out.println("EL INVENTARIO ACTUAL ES:");
        for (int i = 0; i < inventario.length; i++) {
            System.out.println(inventario[i].toString());
        }
    }


    public Producto buscarProducto(String nombre){
        System.out.println("Buscando producto...");
        for (int i = 0; i < inventario.length; i++) {
            if (inventario[i].toString().equals(nombre)){
                System.out.println(inventario[i]);
                return inventario[i];
            }else {
                System.out.println("NO SE ENCUENTRA NADA");
                return null;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "Almacen{" +
                "inventario=" + Arrays.toString(inventario) +
                ", index=" + index +
                '}';
    }
}