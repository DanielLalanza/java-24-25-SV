package arma;

import persoanjes.WarhammerPersonaje;

public interface IArmamentoDefensa {
    void defender(WarhammerPersonaje personajeDefendido, ArmaAtaque aramaAtaque);
}
