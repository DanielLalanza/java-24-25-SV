package arma.Defensa;

import arma.Arma;
import arma.ArmaAtaque;
import arma.IArmamentoDefensa;
import persoanjes.WarhammerPersonaje;

public class Armadura extends ArmaAtaque implements IArmamentoDefensa {
    private final int vidaDefendida=20;

    public Armadura(String nombre) {
        super(nombre);
    }

    @Override
    public void defender(WarhammerPersonaje personajeDefendido, ArmaAtaque aramaAtaque) {

    }
}
