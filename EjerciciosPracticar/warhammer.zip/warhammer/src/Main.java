import arma.Ataque.Arco;
import arma.Ataque.Hacha;
import arma.Ataque.Martillo;
import arma.Ataque.Rebanadora;
import persoanjes.Enanos.Martillador;
import persoanjes.PelesVerde.Goblin;

import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {
        Goblin G1 = new Goblin("Manolo","Caceres");
        G1.setNivel(20);
        Goblin G2 = new Goblin("Mauricio","Cuenca");
        G2.setNivel(20);

        Martillador M1 = new Martillador("Frank", 1000);
        Martillador M2 = new Martillador("Francisco", 1000);

        Arco a1 = new Arco("A1");
        Hacha h1 = new Hacha("H1");
        Martillo m1 = new Martillo("M1");
        Rebanadora r1 = new Rebanadora("R1");
        G1.addArmaAtaque(a1,"Arco");
        G2.addArmaAtaque(h1, "Arco");
        M1.addArmaAtaque(m1);
        M2.addArmaAtaque(r1);

        System.out.println(G1.toString());
    }
}