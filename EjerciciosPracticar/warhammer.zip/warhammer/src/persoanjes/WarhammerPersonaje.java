package persoanjes;

import arma.Arma;
import arma.ArmaAtaque;
import arma.ArmaDefensa;

import java.util.HashMap;

public abstract class WarhammerPersonaje {
    private String nombre;
    private int energia;
    protected HashMap <String, Arma> armas;
    private static int contPeronajes;
    final int ENERGIA_MAX = 200;

    public WarhammerPersonaje(String nombre) {
        this.nombre = nombre;
    }

    public void sumarEnergia() {}
    public static void toNumPersonajes(){}
    public String imprimirArmas() {
        return ("");
    }


    @Override
    public String toString() {
        return "WarhammerPersonaje{" +
                "nombre='" + nombre + '\'' +
                ", energia=" + energia +
                ", armas=" + armas +
                ", ENERGIA_MAX=" + ENERGIA_MAX +
                '}';
    }
}
